"use strict";
(self["webpackChunkkernel_death"] = self["webpackChunkkernel_death"] || []).push([["lib_index_js"],{

/***/ "./lib/index.js"
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_1__);


const plugin = {
    id: 'my-kernel-dead-notify:plugin',
    autoStart: true,
    activate: (app) => {
        const shell = app.shell;
        shell.currentChanged.connect((_, change) => {
            const { newValue } = change;
            if (!newValue || !(newValue instanceof _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_1__.NotebookPanel)) {
                return;
            }
            const sessionContext = newValue.sessionContext;
            if (!sessionContext) {
                return;
            }
            sessionContext.statusChanged.connect((sender, status) => {
                if (status === 'dead') {
                    // Показываем простое модальное окно с одной кнопкой
                    (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.showDialog)({
                        title: 'KERNEL DIED!',
                        body: 'Ядро умерло (restart_limit=0 — авто-перезапуск отключён)',
                        buttons: [
                            _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.Dialog.okButton({
                                label: 'OK'
                            })
                        ],
                        hasClose: true,
                        focusNodeSelector: 'button'
                    });
                }
            });
        });
        console.log('Kernel death notifier (simple modal) activated');
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);


/***/ }

}]);
//# sourceMappingURL=lib_index_js.ba27ba6c64ce350fcb9b.js.map